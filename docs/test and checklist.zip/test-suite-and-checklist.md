# PSB-Aquila Dashboard — Test Suite

**Purpose:** Automated and manual test cases for verifying dashboard functionality after roadmap phases.  
**Usage:** Claude Code runs the automated script via `node docs/test-suite.mjs`. Manual checks are listed separately for Kyle to verify in-browser.  
**Location:** `docs/test-suite.mjs` (automated) + `docs/test-checklist.md` (this file, manual)

---

## Automated Test Script

Save the script below as `docs/test-suite.mjs`. Run with:

```bash
# Requires DATABASE_URL environment variable
# Requires the app to be deployed (tests hit the live API)
node docs/test-suite.mjs https://psb-aquila-dashboard.vercel.app
```

```javascript
/**
 * PSB-Aquila Dashboard — Automated Test Suite
 * 
 * Tests API endpoints, database integrity, and build health.
 * Run after any roadmap phase to verify nothing broke.
 * 
 * Usage: node docs/test-suite.mjs <base_url>
 * Example: node docs/test-suite.mjs https://psb-aquila-dashboard.vercel.app
 * 
 * Exit codes: 0 = all passed, 1 = failures detected
 */

const BASE_URL = process.argv[2] || 'https://psb-aquila-dashboard.vercel.app'

let passed = 0
let failed = 0
let skipped = 0
const failures = []

// ─── Helpers ──────────────────────────────────────────────

async function test(name, fn) {
  try {
    await fn()
    passed++
    console.log(`  ✅ ${name}`)
  } catch (err) {
    failed++
    failures.push({ name, error: err.message })
    console.log(`  ❌ ${name}: ${err.message}`)
  }
}

function skip(name, reason) {
  skipped++
  console.log(`  ⏭️  ${name} (${reason})`)
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed')
}

async function fetchJSON(path, options = {}) {
  const url = `${BASE_URL}${path}`
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  return { status: res.status, data: await res.json() }
}

// ─── 1. Health & Connectivity ─────────────────────────────

console.log('\n📡 1. Health & Connectivity')

await test('API health endpoint responds', async () => {
  const { status, data } = await fetchJSON('/api/health')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data.status === 'ok', `Expected status ok, got ${data.status}`)
})

await test('Database is connected', async () => {
  const { data } = await fetchJSON('/api/health')
  assert(data.database === true, 'Database not connected')
})

// ─── 2. Prospect API ──────────────────────────────────────

console.log('\n👥 2. Prospect API')

await test('GET /api/prospects returns array', async () => {
  const { status, data } = await fetchJSON('/api/prospects')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array response')
  assert(data.length > 0, 'Expected at least 1 prospect')
})

let sampleProspectId = null
await test('Prospects have required fields', async () => {
  const { data } = await fetchJSON('/api/prospects')
  const p = data[0]
  sampleProspectId = p.id
  const required = ['id', 'company', 'category', 'state', 'priority', 'signal_count',
    'rjg_cavity_pressure', 'medical_device_mfg', 'ownership_type', 'prospect_status']
  for (const field of required) {
    assert(field in p, `Missing field: ${field}`)
  }
})

await test('GET /api/prospects?id=X returns single prospect', async () => {
  if (!sampleProspectId) throw new Error('No sample prospect ID')
  const { status, data } = await fetchJSON(`/api/prospects?id=${sampleProspectId}`)
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data.id === sampleProspectId, 'ID mismatch')
  assert(data.company, 'Missing company name')
})

await test('Prospect has conversion_count field', async () => {
  if (!sampleProspectId) throw new Error('No sample prospect ID')
  const { data } = await fetchJSON(`/api/prospects?id=${sampleProspectId}`)
  assert('conversion_count' in data, 'Missing conversion_count (subquery field)')
})

await test('Filter by category works', async () => {
  const { status, data } = await fetchJSON('/api/prospects?category=Converter%2BTooling')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
  if (data.length > 0) {
    assert(data[0].category === 'Converter+Tooling', 'Category filter not applied')
  }
})

await test('Filter by prospect_status works', async () => {
  const { status, data } = await fetchJSON('/api/prospects?prospect_status=Identified')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
})

// ─── 3. Analytics API ─────────────────────────────────────

console.log('\n📊 3. Analytics API')

await test('GET /api/prospects?action=analytics returns all chart data', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=analytics')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data.groups, 'Missing groups')
  assert(data.categories, 'Missing categories')
  assert(data.signals, 'Missing signals')
  assert(data.readiness, 'Missing readiness')
  assert(data.ownership, 'Missing ownership')
})

await test('Analytics respects filters', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=analytics&priority=HIGH%20PRIORITY')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data.groups, 'Missing groups in filtered response')
})

// ─── 4. State Stats & National Map API ────────────────────

console.log('\n🗺️  4. State Stats & National Map API')

await test('GET state-stats returns per-state data', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=state-stats')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data._totals, 'Missing _totals key')
  assert(data._totals.total_prospects > 0, 'No prospects in totals')
  assert(data._totals.states_covered > 0, 'No states covered')
  // Check at least one state has data
  const stateKeys = Object.keys(data).filter(k => k !== '_totals')
  assert(stateKeys.length > 0, 'No state data returned')
  const sampleState = data[stateKeys[0]]
  assert(sampleState.prospect_count > 0, 'State has 0 prospects')
})

await test('State stats include expected fields', async () => {
  const { data } = await fetchJSON('/api/prospects?action=state-stats')
  const stateKeys = Object.keys(data).filter(k => k !== '_totals')
  const sample = data[stateKeys[0]]
  assert('prospect_count' in sample, 'Missing prospect_count')
  assert('categories' in sample, 'Missing categories')
  assert('avg_signal' in sample, 'Missing avg_signal')
  assert('cwp_total' in sample, 'Missing cwp_total')
  assert('priorities' in sample, 'Missing priorities')
  assert('top_companies' in sample, 'Missing top_companies')
})

await test('GET state-reports returns array', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=state-reports')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
})

let stateWithReport = null
await test('State reports have expected fields', async () => {
  const { data } = await fetchJSON('/api/prospects?action=state-reports')
  if (data.length === 0) throw new Error('No state reports found — upload at least one to test')
  const r = data[0]
  stateWithReport = r.state_code
  assert(r.state_code, 'Missing state_code')
  assert(r.state_name, 'Missing state_name')
  assert(r.title, 'Missing title')
  assert(r.researched_at, 'Missing researched_at')
})

await test('GET state-report&state=XX returns full content', async () => {
  if (!stateWithReport) throw new Error('No state with report to test')
  const { status, data } = await fetchJSON(`/api/prospects?action=state-report&state=${stateWithReport}`)
  assert(status === 200, `Expected 200, got ${status}`)
  assert(data.content, 'Missing report content')
  assert(data.content.length > 100, 'Report content seems too short')
})

// ─── 5. Attachments API ───────────────────────────────────

console.log('\n📎 5. Attachments API')

await test('GET attachments for prospect returns array', async () => {
  if (!sampleProspectId) throw new Error('No sample prospect ID')
  const { status, data } = await fetchJSON(`/api/prospects?action=attachments&id=${sampleProspectId}`)
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
})

// ─── 6. Ontology API ─────────────────────────────────────

console.log('\n🧬 6. Ontology API')

let ontologyPopulated = false

await test('GET ontology-stats responds', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=ontology-stats')
  assert(status === 200, `Expected 200, got ${status}`)
  assert('total_entities' in data, 'Missing total_entities')
  assert('total_relationships' in data, 'Missing total_relationships')
  ontologyPopulated = data.total_entities > 0
})

if (ontologyPopulated) {
  await test('Ontology has entity counts by type', async () => {
    const { data } = await fetchJSON('/api/prospects?action=ontology-stats')
    assert(data.entity_counts, 'Missing entity_counts')
    assert(data.entity_counts['Company'] > 0, 'No Company entities — Layer 1 may not have run')
  })

  await test('Ontology has relationship counts', async () => {
    const { data } = await fetchJSON('/api/prospects?action=ontology-stats')
    assert(data.relationship_counts, 'Missing relationship_counts')
    assert(data.total_relationships > 0, 'No relationships — Layer 1 may not have run')
  })

  await test('GET ontology-state-summary returns state data', async () => {
    const { data: stats } = await fetchJSON('/api/prospects?action=state-stats')
    const stateKeys = Object.keys(stats).filter(k => k !== '_totals')
    if (stateKeys.length === 0) throw new Error('No states to test')
    const { status, data } = await fetchJSON(`/api/prospects?action=ontology-state-summary&state=${stateKeys[0]}`)
    assert(status === 200, `Expected 200, got ${status}`)
    assert(data.state === stateKeys[0], 'State mismatch')
  })

  await test('Layer 1 rebuild endpoint responds', async () => {
    // Just verify the endpoint exists and responds — don't actually rebuild during tests
    // A GET to this endpoint should return 405 or similar (it's POST only)
    const res = await fetch(`${BASE_URL}/api/prospects?action=rebuild-ontology-layer1`, { method: 'GET' })
    // This should either 405 or fall through to the GET list — either is fine
    assert(res.status !== 500, 'Rebuild endpoint crashed on GET probe')
  })
} else {
  skip('Ontology entity counts', 'ontology not yet populated')
  skip('Ontology relationship counts', 'ontology not yet populated')
  skip('Ontology state summary', 'ontology not yet populated')
  skip('Layer 1 rebuild endpoint', 'ontology not yet populated')
}

// ─── 7. Ontology Existing Entities (Phase 5) ──────────────

console.log('\n📋 7. Ontology Extraction Support (Phase 5)')

await test('GET ontology-existing-entities responds', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=ontology-existing-entities')
  if (status === 404 || (status === 200 && data.error)) {
    throw new Error('Endpoint not found — Phase 5 may not be deployed yet')
  }
  assert(status === 200, `Expected 200, got ${status}`)
  assert(typeof data === 'object', 'Expected object response')
})

// ─── 8. Ontology Density (Phase 6) ───────────────────────

console.log('\n🌡️  8. Ontology Density (Phase 6)')

await test('GET ontology-density-by-state responds', async () => {
  const { status, data } = await fetchJSON('/api/prospects?action=ontology-density-by-state')
  if (status === 404 || (status === 200 && data.error)) {
    throw new Error('Endpoint not found — Phase 6 may not be deployed yet')
  }
  assert(status === 200, `Expected 200, got ${status}`)
  assert(typeof data === 'object', 'Expected object response')
  if (data._totals) {
    assert('total_entities' in data._totals, 'Missing total_entities in _totals')
  }
})

// ─── 9. Opportunities API ─────────────────────────────────

console.log('\n🎯 9. Opportunities (Pipeline) API')

await test('GET /api/opportunities returns array', async () => {
  const { status, data } = await fetchJSON('/api/opportunities')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
})

await test('GET /api/key-dates returns array', async () => {
  const { status, data } = await fetchJSON('/api/key-dates')
  assert(status === 200, `Expected 200, got ${status}`)
  assert(Array.isArray(data), 'Expected array')
})

await test('GET /api/analytics responds', async () => {
  const { status } = await fetchJSON('/api/analytics')
  assert(status === 200, `Expected 200, got ${status}`)
})

// ─── 10. Auth API ─────────────────────────────────────────

console.log('\n🔐 10. Auth API')

await test('GET /api/auth?action=validate returns without crash', async () => {
  const { status } = await fetchJSON('/api/auth?action=validate')
  // Without a session token, should return 401 or equivalent — not 500
  assert(status !== 500, `Auth validate crashed: ${status}`)
})

await test('Login with bad credentials returns 401', async () => {
  const { status } = await fetchJSON('/api/auth?action=login', {
    method: 'POST',
    body: JSON.stringify({ email: 'nobody@fake.com', pin: '000000' }),
  })
  assert(status === 401 || status === 400, `Expected 401/400, got ${status}`)
})

// ─── 11. Build Verification ──────────────────────────────

console.log('\n🏗️  11. Static Asset Verification')

await test('App index.html loads', async () => {
  const res = await fetch(BASE_URL)
  assert(res.status === 200, `Expected 200, got ${res.status}`)
  const html = await res.text()
  assert(html.includes('Opportunity Tracker') || html.includes('<div id="root"'), 'Missing app markers in HTML')
})

await test('Deep research template exists', async () => {
  const res = await fetch(`${BASE_URL}/prompts/deep-research-template.md`)
  assert(res.status === 200, `Expected 200, got ${res.status}`)
  const text = await res.text()
  assert(text.length > 1000, 'Template seems too short')
  assert(text.includes('{{company}}'), 'Missing {{company}} variable')
})

await test('State research template exists and is complete', async () => {
  const res = await fetch(`${BASE_URL}/prompts/state-research-template.md`)
  assert(res.status === 200, `Expected 200, got ${res.status}`)
  const text = await res.text()
  assert(text.length > 3000, `Template too short (${text.length} chars) — may be truncated`)
  assert(text.includes('{{state_name}}'), 'Missing {{state_name}} variable')
  assert(text.includes('{{state_code}}'), 'Missing {{state_code}} variable')
  assert(text.includes('EXECUTION PRINCIPLES') || text.includes('Execution Principles'), 
    'Missing EXECUTION PRINCIPLES section — template may be truncated')
})

await test('Ontology extraction template exists', async () => {
  const res = await fetch(`${BASE_URL}/prompts/ontology-extraction-template.md`)
  if (res.status === 404) {
    throw new Error('Not found — Phase 5 may not be deployed yet')
  }
  assert(res.status === 200, `Expected 200, got ${res.status}`)
  const text = await res.text()
  assert(text.includes('{{company}}'), 'Missing {{company}} variable')
  assert(text.includes('{{brief_content}}'), 'Missing {{brief_content}} variable')
})

// ─── 12. Data Integrity ──────────────────────────────────

console.log('\n🔍 12. Data Integrity')

await test('No prospects with NULL signal_count', async () => {
  const { data } = await fetchJSON('/api/prospects')
  const nullSignals = data.filter(p => p.signal_count === null)
  assert(nullSignals.length === 0, 
    `${nullSignals.length} prospects have NULL signal_count: ${nullSignals.slice(0, 3).map(p => p.company).join(', ')}...`)
})

await test('No prospects with NULL cwp_contacts', async () => {
  const { data } = await fetchJSON('/api/prospects')
  const nullCWP = data.filter(p => p.cwp_contacts === null)
  assert(nullCWP.length === 0, 
    `${nullCWP.length} prospects have NULL cwp_contacts: ${nullCWP.slice(0, 3).map(p => p.company).join(', ')}...`)
})

await test('All prospects have a state value', async () => {
  const { data } = await fetchJSON('/api/prospects')
  const noState = data.filter(p => !p.state || p.state.trim() === '')
  if (noState.length > 0) {
    console.log(`    ⚠️  ${noState.length} prospects without state: ${noState.slice(0, 5).map(p => p.company).join(', ')}`)
  }
  // Warning, not failure — some infrastructure companies may lack state
})

await test('All prospects have a valid prospect_status', async () => {
  const validStatuses = ['Identified', 'Prioritized', 'Research Complete', 'Outreach Ready', 'Converted', 'Nurture']
  const { data } = await fetchJSON('/api/prospects')
  const invalid = data.filter(p => p.prospect_status && !validStatuses.includes(p.prospect_status))
  assert(invalid.length === 0, 
    `${invalid.length} prospects with invalid status: ${invalid.slice(0, 3).map(p => `${p.company}="${p.prospect_status}"`).join(', ')}`)
})

await test('Prospect count matches state-stats total', async () => {
  const { data: prospects } = await fetchJSON('/api/prospects')
  const { data: stats } = await fetchJSON('/api/prospects?action=state-stats')
  const statsTotal = stats._totals?.total_prospects || 0
  // Stats only count prospects with non-empty state, so statsTotal <= prospects.length
  assert(statsTotal <= prospects.length, 
    `State stats total (${statsTotal}) exceeds prospect count (${prospects.length})`)
  assert(statsTotal > 0, 'State stats show 0 prospects')
})

// ─── 13. Serverless Function Count ───────────────────────

console.log('\n⚡ 13. Serverless Function Limit')

await test('Vercel function count is within limit', async () => {
  // We can't programmatically count deployed functions, but we can verify
  // known endpoints respond (meaning they exist as functions)
  const endpoints = [
    '/api/health',
    '/api/prospects',
    '/api/opportunities',
    '/api/activities',
    '/api/analytics',
    '/api/stage-transitions',
    '/api/key-dates',
    '/api/meeting-minutes',
    '/api/auth',
  ]
  let responding = 0
  for (const ep of endpoints) {
    try {
      const res = await fetch(`${BASE_URL}${ep}`)
      if (res.status !== 404) responding++
    } catch {}
  }
  console.log(`    📊 ${responding}/${endpoints.length} known endpoints responding (limit: 12)`)
  assert(responding >= 5, 'Too few endpoints responding — deployment may be broken')
})

// ─── Summary ─────────────────────────────────────────────

console.log('\n' + '═'.repeat(50))
console.log(`\n📋 Results: ${passed} passed, ${failed} failed, ${skipped} skipped`)

if (failures.length > 0) {
  console.log('\n❌ Failures:')
  for (const f of failures) {
    console.log(`   • ${f.name}: ${f.error}`)
  }
}

console.log()
process.exit(failed > 0 ? 1 : 0)
```

---

## Manual Verification Checklist

Run through these in-browser after the automated tests pass. Check each item.

### Prospects Tab

- [ ] Table renders with all columns: Rank, Group, Status, Company, Category, Location, Priority, Sig, Presses, RJG, Med, CWP, Ownership, Next Step
- [ ] Wrench icon (🔧→Lucide Wrench) appears next to Converter+Tooling categories with in-house tooling
- [ ] Gold star icon appears in RJG column for confirmed users
- [ ] Yellow help-circle appears for RJG "Likely"
- [ ] Shield-check icon appears in Medical column for "Yes"
- [ ] Ownership urgency: red clock for PE + recent M&A, amber clock for PE only
- [ ] Ownership urgency: orange triangle for family-owned 30+ years
- [ ] Ownership urgency: blue people icon for ESOP
- [ ] CWP heat dots visible on company names (amber/orange/red)
- [ ] Sorting works on all sortable columns (click header, asc/desc cycle)
- [ ] Presets filter correctly: Home Turf, Warm Leads, Ready for Research, etc.
- [ ] Dropdown filters work: Group, Category, Priority, Corridor, Status
- [ ] Icon legend visible in filter bar (or expandable via "ⓘ Icon guide" link)
- [ ] Search box filters companies by name/city/state
- [ ] CSV export works (filtered and all)
- [ ] Click row → ProspectDetail panel opens

### Prospect Detail Panel

- [ ] "Why this company" hook line appears below company name
- [ ] Hook line content makes sense (RJG, tooling, press count, legacy, ownership, CWP)
- [ ] Certification badges render as colored pills (purple=medical, blue=auto, gray=aero)
- [ ] All collapsible sections open/close
- [ ] Status dropdown editable
- [ ] Outreach group dropdown editable
- [ ] "Generate Research Prompt" button works → modal opens, prompt injects variables
- [ ] "Attach Research Brief" button works → paste markdown, preview, save
- [ ] If brief exists: accordion sections render, copy/delete work
- [ ] "Promote to Pipeline" button visible for Outreach Ready / Converted status
- [ ] Conversion count badge visible if prospect has been converted

### Prospect Charts (sub-view)

- [ ] Toggle between Table and Charts views
- [ ] Group Summary cards render with counts
- [ ] Category Breakdown chart renders
- [ ] Manufacturing Corridors chart renders (NOT old Tier 1/2/3)
- [ ] Signal Analysis chart renders
- [ ] Readiness Scorecard renders
- [ ] Ownership Profile renders
- [ ] Clicking chart elements filters the table

### Pipeline Tab

- [ ] Kanban board renders with 5 stages (Channel Routing → Complete)
- [ ] Drag-and-drop moves cards between stages
- [ ] Empty state shows "Promote prospects from Prospects tab" link
- [ ] The "Prospects tab" link navigates correctly (hash routing)
- [ ] Opportunity detail panel opens on card click
- [ ] "No Fit" button on Channel Routing cards works

### National Map Tab

- [ ] SVG map renders all 50 states + DC
- [ ] All 5 base metrics work: Prospect Count, Signal Strength, CWP Density, Priority Mix, Research Freshness
- [ ] Metric pills highlight on selection
- [ ] InfoTooltips on metric pills render at readable width (not skinny)
- [ ] Hover tooltip follows cursor with state stats
- [ ] Click state → detail panel opens
- [ ] Detail panel shows: summary stats, priority breakdown, top companies
- [ ] Research report section works (accordion, freshness badge, upload, copy)
- [ ] No duplicate "Run State Research" buttons
- [ ] "Run State Research" → StatePromptBuilderModal opens
- [ ] Ontology Summary section visible (shows data if populated, empty state if not)
- [ ] Legend updates per metric
- [ ] Dynamic subtitle updates per metric
- [ ] Orientation card collapsible, persists dismiss in localStorage

### National Map — Ontology Density (after Phase 5 of roadmap)

- [ ] 6th metric pill "Ontology Density" appears
- [ ] States color by density when selected
- [ ] Tooltip shows density, entity count, relationship count
- [ ] Legend displays decimal format
- [ ] OntologySummary shows Layer 1/2 breakdown bar
- [ ] OntologySummary shows entity type distribution

### Navigation & Routing

- [ ] URL shows hash: `/#prospects`, `/#pipeline`, `/#national-map`
- [ ] Refresh preserves current tab
- [ ] Browser back button navigates between tabs
- [ ] Browser forward button navigates between tabs
- [ ] Invalid hash (e.g., `/#garbage`) defaults to Pipeline
- [ ] Empty hash defaults to Pipeline
- [ ] Tab icons visible (Building2, Kanban, Map)
- [ ] Analytics tab NOT visible in nav
- [ ] Manually navigating to `/#analytics` defaults to Pipeline

### Auth

- [ ] Login screen appears when not authenticated
- [ ] Login with valid email + PIN works
- [ ] Session persists across page refreshes
- [ ] Logout works
- [ ] Admin gear icon visible for Kyle only
- [ ] Admin panel: can view users, reset PINs

### Data Integrity (spot check)

- [ ] Pick 3 random prospects — verify detail panel data looks reasonable
- [ ] Pick a state with a research report — verify report content renders correctly
- [ ] Verify no "April 1, 2026" standalone date section in report accordion
- [ ] Check that prospect count in UI matches "X companies" label in filters

---

*Save automated script as `docs/test-suite.mjs`. Save this checklist as `docs/test-checklist.md`. Run automated tests first, then manual checks.*
