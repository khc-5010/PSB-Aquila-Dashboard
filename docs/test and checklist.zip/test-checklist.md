# PSB-Aquila Dashboard — Manual Test Checklist

**Purpose:** In-browser verification after automated tests pass.  
**Usage:** Open the dashboard and check each item. Run after roadmap phases complete.

---

## Prospects Tab — Table View

- [ ] Table renders with all columns: Rank, Group, Status, Company, Category, Location, Priority, Sig, Presses, RJG, Med, CWP, Ownership, Next Step
- [ ] Wrench icon appears next to categories with in-house tooling
- [ ] Gold star icon appears in RJG column for confirmed users
- [ ] Yellow help-circle appears for RJG "Likely"
- [ ] Shield-check icon appears in Medical column for "Yes"
- [ ] Ownership urgency: red clock for PE + recent M&A, amber clock for PE only
- [ ] Ownership urgency: orange triangle for family-owned 30+ years
- [ ] Ownership urgency: blue people icon for ESOP
- [ ] CWP heat dots visible on company names (amber/orange/red by threshold)
- [ ] Sorting works on all sortable columns (click header, asc/desc/default cycle)
- [ ] Presets filter correctly: Home Turf, Warm Leads, Ready for Research, Converter+Tooling, Medical Molders
- [ ] Dropdown filters work: Group, Category, Priority, Corridor, Status
- [ ] Icon legend visible (or expandable via "ⓘ Icon guide" link in filter bar)
- [ ] Search box filters companies by name/city/state
- [ ] CSV export works (filtered and all)
- [ ] Click row → ProspectDetail panel opens
- [ ] Add Company modal works (+ Add Company button)
- [ ] Import modal works (Import button → upload → preview → confirm)

## Prospects Tab — Detail Panel

- [ ] "Why this company" hook line appears below company name
- [ ] Hook line content makes sense (RJG, tooling, press count, legacy, ownership, CWP)
- [ ] Certification badges render as colored pills (purple=medical, blue=auto, gray=aero, green=environmental)
- [ ] All collapsible sections open/close correctly
- [ ] Status dropdown editable → saves on change
- [ ] Outreach group dropdown editable → saves on change
- [ ] "Generate Research Prompt" button → modal opens with injected variables → copy works
- [ ] "Attach Research Brief" → paste markdown → preview → save → status auto-advances
- [ ] If brief exists: accordion sections render, copy raw markdown works, delete works
- [ ] "Promote to Pipeline" button visible for Outreach Ready / Converted status
- [ ] Conversion count purple badge visible if prospect has active opportunities
- [ ] Close panel (X button) works

## Prospects Tab — Charts View

- [ ] Toggle between Table and Charts views preserves filter state
- [ ] Group Summary cards render with correct counts
- [ ] Category Breakdown bar chart renders
- [ ] Manufacturing Corridors donut chart renders (NOT old Tier 1/2/3)
- [ ] Signal Analysis chart renders
- [ ] Readiness Scorecard renders
- [ ] Ownership Profile renders
- [ ] Clicking chart elements updates filter → table reflects it

## Pipeline Tab

- [ ] Kanban board renders with 5 stages: Channel Routing, Client Readiness, Project Setup, Active, Complete
- [ ] Stage headers show opportunity counts
- [ ] Drag-and-drop moves cards between stages
- [ ] Empty state shows "Promote prospects from Prospects tab" link
- [ ] The "Prospects tab" link uses hash routing (`/#prospects`)
- [ ] Opportunity detail panel opens on card click
- [ ] "No Fit" button visible on Channel Routing cards
- [ ] No Fit → deletes opportunity, sets source prospect to Nurture
- [ ] Metrics bar at top shows Pipeline Value, Active Opportunities, Avg Cycle Time, Win Rate

## National Map Tab

- [ ] SVG map renders all 50 states + DC
- [ ] All 5 base metrics work: Prospect Count, Signal Strength, CWP Density, Priority Mix, Research Freshness
- [ ] Metric pill buttons highlight on selection
- [ ] InfoTooltips on metric pills render at readable width (not skinny/clipped)
- [ ] Hover tooltip follows cursor and shows state stats
- [ ] Freshness metric shows green/yellow/red/gray categorical colors
- [ ] Click state → detail panel slides in from right
- [ ] Detail panel shows: summary stats, priority breakdown bar, top companies table
- [ ] Research report section: accordion sections, freshness badge, "new prospects since report" counter
- [ ] "Upload New Report" → modal → paste or drag file → save
- [ ] "Run State Research" → StatePromptBuilderModal → select parameters → copy to clipboard
- [ ] No duplicate "Run State Research" buttons (only one, inside the report section)
- [ ] Ontology Summary section visible (data if populated, empty state message if not)
- [ ] Legend updates per metric selection
- [ ] Dynamic subtitle updates per metric selection
- [ ] Orientation card collapsible → persists dismiss state on refresh

## National Map — Ontology Density (after Roadmap Phase 5)

- [ ] 6th metric pill "Ontology Density" appears in selector
- [ ] States color by density gradient when selected
- [ ] Tooltip shows: density per prospect, entity count, relationship count
- [ ] Legend shows decimal format (not integer)
- [ ] OntologySummary shows Layer 1 vs Layer 2 proportion bar
- [ ] OntologySummary shows entity type distribution mini-bars
- [ ] States with no ontology data show as gray

## Navigation & Routing

- [ ] URL bar shows hash: `/#prospects`, `/#pipeline`, `/#national-map`
- [ ] Refresh page → stays on current tab (not reset to Pipeline)
- [ ] Browser back button → navigates to previous tab
- [ ] Browser forward button → navigates forward
- [ ] Invalid hash (e.g., `/#garbage`) → defaults to Pipeline
- [ ] Empty URL (no hash) → defaults to Pipeline
- [ ] Tab icons visible: Building2 (Prospects), Kanban (Pipeline), Map (National Map)
- [ ] Analytics tab NOT visible in navigation
- [ ] Navigating to `/#analytics` → defaults to Pipeline

## Auth System

- [ ] Login screen appears when not authenticated
- [ ] Login with valid email + 6-digit PIN → authenticates successfully
- [ ] Session persists across page refreshes (no re-login required)
- [ ] Logout button works → returns to login screen
- [ ] Admin gear icon visible ONLY for Kyle
- [ ] Admin panel: view users list, change user details, reset PINs
- [ ] DB connection indicator shows green "Connected" in header

## Data Integrity (Spot Check)

- [ ] Pick 3 random prospects → detail panel data looks reasonable and complete
- [ ] Pick a state with a research report → report content renders in accordion
- [ ] No standalone date sections in report accordion (e.g., "April 1, 2026" as its own section)
- [ ] Prospect count in filter bar matches expected total
- [ ] At least one prospect has a research brief attached → accordion renders correctly

## Ontology (after Roadmap Phase 1)

- [ ] `GET /api/prospects?action=ontology-stats` returns non-zero counts
- [ ] Click a state on National Map → Ontology Summary shows certifications, technologies, ownership mix
- [ ] Certification counts in Ontology Summary look reasonable (ISO 9001 should be most common)
- [ ] RJG Technology entity appears for states with confirmed RJG users

## Ontology Extraction (after Roadmap Phase 4)

- [ ] Open a prospect with a research brief → "Extract Ontology" button visible
- [ ] Click "Extract Ontology" → modal shows prompt with brief content + existing entities
- [ ] "Copy to Clipboard" works
- [ ] "Import Extraction" button visible → paste JSON → preview → import
- [ ] After import, ontology-stats shows increased counts

## Auto-Trigger (after Roadmap Phase 2)

- [ ] Bulk import companies → ontology stats increase without manual rebuild
- [ ] Add single company with certifications → that company appears in ontology
- [ ] Edit a prospect's certifications → ontology relationships update
- [ ] Edit outreach_group → no ontology rebuild triggered (check via ontology-stats timestamps)

---

*Last updated: April 3, 2026. Update this checklist as new features ship.*
